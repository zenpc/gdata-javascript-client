/* Copyright (c) 2007 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @fileoverview Demonstrates using the Javascript GData client library
 * to retrieve, insert and delete stocks data from a Spreadsheets feed.
 *
 * @author rpropper@google.com (Ryan Propper)
 */

// Default value for the Spreadsheets feed URI.  This is a demo page
// with values for several ticker symbols.
var DEFAULT_FEED_URI = 'http://spreadsheets.google.com/feeds/list/' +
    'o10288305351702791548.4654213255190941943/od6/public/values';

// Number of columns in the spreadsheet.
var NUM_COLS = 9;

// Default values for feed URI, username and password.  Can be changed
// from the Options dialog in the Google Gadget.
var STOCKS_feedUri = DEFAULT_FEED_URI, STOCKS_username = '',
    STOCKS_password = '';

// The GData service object.
var STOCKS_service = new GDataGoogleService('wise', 'gdata-js-sample-stock');

// Ticker and number of shares owned (when user inserts a new row).
var STOCKS_ticker, STOCKS_shares;

// The array of cells received from the Spreadsheets feed.
var STOCKS_cells;

// Number of cells successfully added in the current row (when inserting
// a new stock).
var STOCKS_numInsertsReceived;

/**
 * Refreshes the list of stocks by removing all content items and
 * fetching the latest Spreadsheets feed.
 */
function refreshDisplay() {
  pluginHelper.RemoveAllContentItems();
  getFeed();
}

/**
 * Sets the GDataGoogleService's username and password fields to match
 * what the user has entered in the Options dialog.
 */
function setAuthentication() {
  if (!(STOCKS_username === '' || STOCKS_password === '')) {
    STOCKS_service.username = STOCKS_username;
    STOCKS_service.password = STOCKS_password;
    STOCKS_service.accountType = 'HOSTED_OR_GOOGLE';
  }
}

/**
 * Retrieves the Spreadsheets feed and specifies display as the
 * callback function to be invoked when the feed is received.
 */
function getFeed() { 
  var query = new GDataQuery(STOCKS_feedUri);
  setAuthentication();

  STOCKS_service.getFeed(query.getUri(), display);
}

/**
 * Callback function for the Spreadsheets feed.  Adds the entries
 * into an Array of cells and calls displayEntries to display them
 * in the gadget view.
 *
 * @param {Object} feedRoot the Spreadsheets feed received.
 */
function display(feedRoot) {
  pluginHelper.RemoveAllContentItems();

  if (feedRoot == null) {
    view.alert('Could not retrieve feed; check URL and authentication.');
  } else {
    var entries = feedRoot.feed.entry;
    cells = new Array();

    for (var i = 0; i < entries.length; ++i) {
      var name = entries[i].gsx$ticker.$t;

      cells[name] = new Object;
      cells[name].price = entries[i].gsx$price.$t;
      cells[name].shares = entries[i].gsx$shares.$t;
      cells[name].total = entries[i].gsx$total.$t;

      cells[name].high = entries[i].gsx$high.$t;
      cells[name].low = entries[i].gsx$low.$t;

      cells[name].change = entries[i].gsx$change.$t;
      cells[name].changepct = entries[i].gsx$changepercentage.$t;

      cells[name].datadelay = entries[i].gsx$datadelay.$t;

      for (var j = 0; j < entries[i].link.length; ++j) {
        if (entries[i].link[j].rel == 'edit') {
          cells[name].link = entries[i].link[j].href;
          break;
        }
      }
    }

    displayEntries();
  }
}

/**
 * Displays each row in the spreadsheet as a Gadgets content item
 * showing its ticker symbol, current price, number of shares owned
 * and total value of shares owned.
 */
function displayEntries() {
  var col, row;
  contentArea.contentFlags = gddContentFlagHaveDetails;

  for (var i in cells) {
    var item = new ContentItem();

    // Set up the content item.
    item.heading = i + ': $' + parseFloat(cells[i].price).toFixed(2);
    item.source = cells[i].shares + ' shares, total $' +
      parseFloat(cells[i].total).toFixed(2);
    item.layout = gddContentItemLayoutNews;
    item.flags = gddContentItemFlagHighlighted;
    item.open_command = 'http://finance.google.com/finance?q=' + i;

    item.onDetailsView = onDetailsView;
    item.onRemoveItem = onRemoveItem;

    // Add the item to the display.
    pluginHelper.AddContentItem(item, gddItemDisplayInSidebar); 
  }
}

/**
 * Callback function to alert the user of an error that occurs on inserting
 * or deleting an entry.
 *
 * @param {Object} error The Error object returned by the GData service.
 */
function handleError(error) {
  view.alert('Error: ' + error.message);
}

/**
 * Invoked by Google Desktop when the details view of a ContentItem
 * is opened.
 *
 * @param {Object} item The ContentItem object whose details view is
 *     opened.
 */
function onDetailsView(item) {
  var html = '<html><head></head><body>';
  
  var ticker = item.heading.substr(0, item.heading.indexOf(':'));
  html += '<font face="Verdana" size="-1">';
  html += '<p><b>' + ticker + ' ($' +
          parseFloat(cells[ticker].price).toFixed(2) +
          ')</b> - <a href="http://finance.google.com/finance?q=' + ticker +
          '">view on Google Finance</a><br />';
  html += '<ul><li>Low: $' + parseFloat(cells[ticker].low).toFixed(2) +
          ', high: $' + parseFloat(cells[ticker].high).toFixed(2) + '</li>';
  if (parseFloat(cells[ticker].change) >= 0) {
    html += '<li>Change: <font color="green">' + 
            (cells[ticker].change.charAt(0) == '+' ? '' : '+') +
            cells[ticker].change + ' (' +
            (parseFloat(cells[ticker].changepct) * 100).toFixed(2) + 
            '%)</font></li>';
  } else {
    html += '<li>Change: <font color="red">' + cells[ticker].change +
            ' (' + (parseFloat(cells[ticker].changepct) * 100).toFixed(2) + 
            '%)</font></li>';
  }
  html += '<li>Data delay: ' + cells[ticker].datadelay + ' minutes</li></ul>';
  html += '<p><b>Click <i>Remove</i> below to remove this entry from your' +
          ' spreadsheet.</b></p>';
  html += '</font></body></html>';

  var detailsView = new DetailsView();

  detailsView.SetContent('', 0 /* time_created */, html,
                         true, item.layout);
  detailsView.html_content = true;

  var details = {};
  details.details_control = detailsView;

  return details;
};

/**
 * Invoked by Google Desktop when a ContentItem is removed.
 *
 * @param {Object} item The ContentItem object to be removed
 * @return {Boolean} true to cancel, false to continue and remove.
 */
function onRemoveItem(item) {
  var ticker = item.heading.substr(0, item.heading.indexOf(':'));
  STOCKS_service.deleteEntry(cells[ticker].link, refreshDisplay, handleError);

  return true;
}

/**
 * Invoked by Google Desktop when the Options dialog is shown.  Draws
 * the controls to add a new stock to the spreadsheet, as well as the
 * controls to set authentication and feed URI options.
 *
 * @param {Object} wnd Gadget API WindowControl object.
 * @return {Boolean} false to cancel, true or nothing to continue. 
 */
function onShowOptionsDlg(wnd) {
  wnd.AddControl(gddWndCtrlClassLabel, gddWndCtrlTypeNone, 'addLabel',
                 ADD_NEW_STOCK, 10, 10, 80, 20);

  wnd.AddControl(gddWndCtrlClassLabel, gddWndCtrlTypeNone, 'tickerLabel',
                 TICKER + ':', 10, 35, 40, 20);
  wnd.AddControl(gddWndCtrlClassEdit, gddWndCtrlTypeNone, 'ticker',
                 '', 50, 35, 60, 20);

  wnd.AddControl(gddWndCtrlClassLabel, gddWndCtrlTypeNone, 'sharesLabel',
                 SHARES + ':', 10, 60, 40, 20);
  wnd.AddControl(gddWndCtrlClassEdit, gddWndCtrlTypeNone, 'shares',
                 '', 50, 60, 60, 20);

  wnd.AddControl(gddWndCtrlClassLabel, gddWndCtrlTypeNone, 'authLabel',
                 AUTH, 10, 95, 80, 20);

  wnd.AddControl(gddWndCtrlClassLabel, gddWndCtrlTypeNone, 'feedUriLabel',
                 FEED_URI + ':', 10, 120, 60, 20);
  wnd.AddControl(gddWndCtrlClassEdit, gddWndCtrlTypeNone, 'feedUri',
                 STOCKS_feedUri, 70, 120, 240, 20);

  wnd.AddControl(gddWndCtrlClassLabel, gddWndCtrlTypeNone, 'userNameLabel',
                 USER_NAME + ':', 10, 150, 60, 20);
  wnd.AddControl(gddWndCtrlClassEdit, gddWndCtrlTypeNone, 'username',
                 STOCKS_username, 70, 150, 120, 20);
  
  wnd.AddControl(gddWndCtrlClassLabel, gddWndCtrlTypeNone, 'passwordLabel',
                 PASSWORD + ':', 10, 180, 60, 20);
  wnd.AddControl(gddWndCtrlClassEdit, gddWndCtrlTypeEditPassword, 'password',
                 STOCKS_password, 70, 180, 120, 20);  

  // Set the onClose handler
  wnd.onClose = onOptionsDlgClosed;
}

/**
 * Called to initialize the plug-in's options dialog before displaying it.
 *
 * @param {Object} wnd Gadget API WindowControl object.
 * @param {Numeric} code Code indicating which button was clicked.
 */
function onOptionsDlgClosed(wnd, code) {
  if (code == gddIdOK) {
    STOCKS_ticker = wnd.GetControl('ticker').value;
    STOCKS_shares = wnd.GetControl('shares').value;

    if (!(STOCKS_ticker === '' || STOCKS_shares === '')) {
      getCellEditUris();
    } else {
      STOCKS_feedUri = wnd.GetControl('feedUri').value;

      STOCKS_username = wnd.GetControl('username').value;
      STOCKS_password = wnd.GetControl('password').value;
      
      setAuthentication();
      refreshDisplay();
    }

  } else if (code == gddIdCancel) {
    // Do nothing.
  }
}

/**
 * Callback function to respond when a cell is inserted in a new row. Since
 * the row is constructed cell by cell using the cells feed, we only want to
 * refresh the display when all cells the row have been inserted.
 */
function onCellInserted() {
  if (++STOCKS_numInsertsReceived == NUM_COLS) {
    refreshDisplay();
  }
}

/**
 * To insert a new row, we execute an HTTP PUT to each cell in that row
 * to update it.  This function retrieves the edit URIs for each cell
 * in the new row.
 */
function getCellEditUris() {
  var curRow = 2;
  for (var i in cells) {
    curRow++;
  }

  var cellsFeedUri = STOCKS_feedUri.replace(/list/, "cells");
  cellsFeedUri += '?min-row=' + curRow + '&max-row=' + curRow + 
                  '&max-col=' + NUM_COLS + '&return-empty=true';

  var query = new GDataQuery(cellsFeedUri);
  STOCKS_service.getFeed(query.getUri(), receivedCellEditUris);
}

/**
 * Callback function for when the row edit URIs are received.
 *
 * @param {Object} feedRoot the Spreadsheets feed received.
 */
function receivedCellEditUris(feedRoot) {
  var entries = feedRoot.feed.entry;

  var formulae = new Array('', 'price', 'high', 'low', 'datadelay', 'change',
                           'changepct');

  STOCKS_numInsertsReceived = 0;
  updateEntry(entries[0], STOCKS_ticker);

  for (var i = 1; i < formulae.length; i++) {
    var curFormula = '=GoogleFinance(R[0]C[-' + i + '], "' + formulae[i] + '")';
    if (formulae[i] == 'changepct') {
      curFormula += '/100';
    }

    updateEntry(entries[i], curFormula);
  }

  updateEntry(entries[7], STOCKS_shares);
  updateEntry(entries[8], '=R[0]C[-7]*R[0]C[-1]');
}

/**
 * Updates a single cell to have the specified value.
 *
 * @param {json} entry the cell to update.
 * @param {String} value the new value for that cell.
 */
function updateEntry(entry, value) {
  entry.xmlns = new Object;
  entry['xmlns'] = 'http://www.w3.org/2005/Atom';
  entry['xmlns$openSearch'] = 'http://a9.com/-/spec/opensearchrss/1.0/';
  entry['xmlns$gs'] = 'http://schemas.google.com/spreadsheets/2006';
  entry['xmlns$gd'] = 'http://schemas.google.com/g/2005';

  entry.gs$cell.inputValue = value;

  STOCKS_service.updateEntry(entry.link[1].href, entry, onCellInserted, handleError);
}
  
/**
 * Invoked by Google Desktop when the gadget is opened.
 */
function view_onOpen() {
  // Set the handler to be called when the options dialog is shown.
  plugin.onShowOptionsDlg = onShowOptionsDlg;
  refreshDisplay();

  // Refresh the display every minute.
  setInterval("refreshDisplay()", 60000);
}
