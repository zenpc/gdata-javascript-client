#!/bin/sh

rm -f *.zip *.gg
zip -r stock_widget_gd.zip *
cp stock_widget_gd.zip stock_widget_gd.gg

exit 0
