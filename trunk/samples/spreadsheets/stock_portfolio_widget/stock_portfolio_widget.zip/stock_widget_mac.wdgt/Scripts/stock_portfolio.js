// Copyright (c) 2007 Google Inc.
// All Rights Reserved.

/**
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ 

/**
 * @Stock_Portfolio.js This is the main javascript file where 
 * demonstrates using GData JavaScript Client Library to display 
 * stock quotes as well as update and delete the data.
 * @author api.vli(Vivian Li)
 *
 * Version: 1.0
 */

var username, password, spreadsheetKey, worksheetId, feedUrl, newStock, shares;

/**
 * Loads the widget preference settings.  If the username and password is 
 * not provided, use the default public sample spreadsheet.
 */
function setup() {
  if (window.widget) {
    username = widget.preferenceForKey(makeKey("username")) || '';
    password = widget.preferenceForKey(makeKey("password")) || '';
    spreadsheetKey = widget.preferenceForKey(makeKey("spreadsheetKey")) || '';
    worksheetId = widget.preferenceForKey(makeKey("worksheetId")) || '';
    if (!username) { 
      username = ''; 
    }
    if (!password) { 
      password = ''; 
    }
    if (!spreadsheetKey) { 
      spreadsheetKey = 'o10288305351702791548.4654213255190941943'; 
    }
    if (!worksheetId) { 
      worksheetId ='od6'; 
    }
    document.getElementById("username").value = username;
    document.getElementById("password").value = password;
    document.getElementById("spreadsheetKey").value = spreadsheetKey;
    document.getElementById("worksheetId").value = worksheetId;
    gDoneButton = new AppleGlassButton(
        document.getElementById("doneButton"), "Done", hidePrefs);
    gAddButton = new AppleGlassButton(
        document.getElementById("addButton"), "+", addStock);
    if (username == '' || password =='' ) {
      loadPublicSpreadsheetsFeed(
          'http://spreadsheets.google.com/feeds/list/' +
	  'o10288305351702791548.4654213255190941943/od6/public/values',
          function(feed) {
	    listStocks(feed);
	  }, displayError);
    } else {
      loadPrivateSpreadsheetsFeed(
          'http://spreadsheets.google.com/feeds/list/' + 
	   spreadsheetKey + '/' + worksheetId + 
	   '/private/full', username, password, 
	   function(feed) {
	     listStocks(feed);
	   }, displayError);	
    }
  }
}

/**
 * Retrieves stock information which users added to the preferences 
 * and cialls insertNewEntry() function
 */
function addStock() {
  var ticker = document.getElementById("newstock").value;
  var shares = document.getElementById("shares").value;
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  var spreadsheetKey = document.getElementById("spreadsheetKey").value;
  var worksheetId = document.getElementById("worksheetId").value;
  if (!ticker) {  
    displayError("You must enter a ticker.");
  } else if (!shares) {
    displayError("You must enter a number of shares.");
  } else if (!username || !password) {
    displayError("You must enter a username and password.");
  } else if (!spreadsheetKey || !worksheetId) {
    displayError("Please enter a value spreadsheet key and worksheet id.");
  } else {
    displayError("Updating...");	
    insertNewEntry(ticker, shares, username, password, 
        spreadsheetKey, worksheetId,
        function() { 
          var feedUrl = 'http://spreadsheets.google.com/feeds/list/' + 
              spreadsheetKey + '/' + worksheetId + '/private/full';
	  finishUpdate(feedUrl, username, password);
        },
        function(errorMsg) { displayError(errorMsg); });
  }
}

/**
 * Displays error message based on HTML element id.
 */
function displayError(msg) {
  document.getElementById("userdisplay").innerHTML = msg;
}

/**
 * showPrefs() is called when the preferences flipper is clicked upon.  
 * It freezes the front of the widget, hides the front div, unhides 
 * the back div, and then flips the widget over.
 */
function showPrefs()
{
  var front = document.getElementById("front");
  var back = document.getElementById("back");
	
  if (window.widget) 
    widget.prepareForTransition("ToBack");		

  front.style.display = "none";		
  back.style.display = "block";		
	
  if (window.widget)
    setTimeout ('widget.performTransition();', 0);		

  document.getElementById('fliprollie').style.display = 'none';  
}

/** 
 * hidePrefs() is called by the done button on the back side of the widget. 
 * It performs the opposite transition as showPrefs() does. It also saves
 * preference information such as username, password, spreadsheetKey, 
 * and worksheetId in the widget preferences.
 */
function hidePrefs()
{
  if (window.widget) {
    username = document.getElementById("username").value;
    password = document.getElementById("password").value;
    spreadsheetKey = document.getElementById("spreadsheetKey").value;
    worksheetId = document.getElementById("worksheetId").value;
    if (username && !password) {
      displayError("Please enter a password.");
    } else if (password && !username) {
      displayError("Please enter a username.");
    } else if (!spreadsheetKey) {
      displayError("Please enter a spreadsheet key.");
    } else if (!worksheetId) {
      displayError("Please enter a worksheet id.");	
    } else if ( username == '' || password == '' || 
      spreadsheetKey == '' || worksheetId == '' ) {
      loadPublicSpreadsheetsFeed(
          'http://spreadsheets.google.com/feeds/list/' +
          'o10288305351702791548.4654213255190941943/od6/public/values',
	  function(feed) {
	    listStocks(feed);
	    hidePrefs_();
          },
	  function(errorMsg) {
	    displayError(errorMsg);
          });
    } else {
      loadPrivateSpreadsheetsFeed(
          'http://spreadsheets.google.com/feeds/list/' + 
          spreadsheetKey + '/' + worksheetId + 
          '/private/values', username, password, 
	  function(feed) {
	    listStocks(feed);
	    hidePrefs_();
	  },
	  function(errorMsg) {
	    displayError(errorMsg); });	
     }
  }		
}

/**
 * hidePrefs_ is called by hidePrefs().
 * It will refetch the feed to display on the front and flip the 
 * panel to the front.
 */
function hidePrefs_()
{
  widget.setPreferenceForKey(username, makeKey("username"));
  widget.setPreferenceForKey(password, makeKey("password"));
  widget.setPreferenceForKey(spreadsheetKey, makeKey("spreadsheetKey"));
  widget.setPreferenceForKey(worksheetId, makeKey("worksheetId"));
		
  var front = document.getElementById("front");
  var back = document.getElementById("back");
	
  if (window.widget)
    widget.prepareForTransition("ToFront");		
	
  back.style.display = "none";			
  front.style.display = "block";		
	
  if (window.widget)
    setTimeout ('widget.performTransition();', 0);			
}

/**
 * Loads the sample public Spreadsheets feed that contains Google Finance data
 * such as ticker, market price, high, low, volume and so on.
 * To learn how to use GoogleFinance function in Google Spreadsheets, 
 * go to 
 * http://docs.google.com/support/spreadsheets/bin/answer.py?answer=54198&topic=9373.
 *
 * @param {String} feedUrl feed URL to fetch.
 */
function loadPublicSpreadsheetsFeed(feedUrl, successHandler, errorHandler) {
  var service = new google.gdata.client.GoogleService('wise', 'gdata-js-sample-stock');
  var query = new google.gdata.client.Query(feedUrl);
  service.getFeed(query.getUri(), successHandler, errorHandler);								 
}

/** 
 * Loads private Spreadsheets feed when username, password, spreadsheet 
 * and worksheet are filled in, in the widget preferences.
 *
 * @param {String} feedUrl feed url that to fetch
 * @param {String} username user name
 * @param {String} password password
 */
function loadPrivateSpreadsheetsFeed(
    feedUrl, username, password, successHandler, errorHandler) {
  var service = new google.gdata.client.GoogleService("wise", "gdata-js-sample-stock");
  var query = new google.gdata.client.Query(feedUrl);
  service.username = username;
  service.password = password;
  service.accountType = "HOSTED_OR_GOOGLE";
  service.getFeed(query.getUri(), successHandler, errorHandler);
}

/**
 * Callback function for the GData JS Client Library to call with a feed of
 * stocks retrieved.
 *
 * @param {object} feedRoot the spreadsheet feed object that is retrieved
 */ 
function listStocks(feedRoot) {
  var entries = feedRoot.feed.entry;
  var stockDiv = document.getElementById('stock');

  if (stockDiv.childNodes.length > 0) 
    stockDiv.removeChild(stockDiv.childNodes[0]);  

  var ul = document.createElement('ul');
  var table = document.createElement("table");
  table.setAttribute("cellpadding", "2");
  table.setAttribute("border", "1");
  table.setAttribute("cellspacing", "2");
  var header = document.createElement("thead");
  var headerTr = document.createElement("tr");
  var tbody = document.createElement("tbody");
  header.appendChild(headerTr);
  table.appendChild(header);
  table.appendChild(tbody);

  for (var i = 0; i < entries.length; i++) {
    var row = document.createElement("tr");
    var entry = entries[i];    
    var j = 0;
    for (child in entry) {
      if (child.substring(0,3) == 'gsx') {
	// pick the four columns we want to display on the widget.
	if ( j == 0 || j == 1 || j == 7 || j == 8) {
	  var td = document.createElement("td");
          td.innerHTML = entry[child].$t
          row.appendChild(td);
	}
	++j;
      }
    }
    tbody.appendChild(row);
  }
  stockDiv.appendChild(table);
  scrollBarLoaded();
}


/**
 * Inserts a new row with the given ticker and shares. First, we 
 * retrieve a list feed to count the number of rows, and then we 
 * insert cells on the next row using a cell feed.
 * 
 * @param {String} ticker the stock ticker
 * @param {String} shares the number of stock shares owned
 * @param {String} username username
 * @param {String} password password
 * @param {String} spreadsheetKey spreadsheet key
 * @param {String} worksheetId worksheet id
 * @param {Function} succHandler the function to call on success
 * @param {Function} failHandler the function to call on failure
 */
function insertNewEntry(ticker, shares, username, password, 
    spreadsheetKey, worksheetId, succHandler, failHandler) {
  var service = new google.gdata.client.GoogleService('wise', 'gdata-js-sample-stock');
  var feedUrl = 'http://spreadsheets.google.com/feeds/list/' + 
		spreadsheetKey + '/' + worksheetId + 
		'/private/full';
							 
  var cellFeedUrl = 'http://spreadsheets.google.com/feeds/cells/' + 
		    spreadsheetKey + '/' + worksheetId + 
		    '/private/full';
							 
  service.username = username;
  service.password = password;
  service.accountType = 'HOSTED_OR_GOOGLE';
	
  var cellEntries = ['', 
		     ticker, 
                     '=GoogleFinance(R[0]C[-1], "price")',
		     '=GoogleFinance(R[0]C[-2], "high")',
		     '=GoogleFinance(R[0]C[-3], "low")',
		     '=GoogleFinance(R[0]C[-4], "datadelay")',
		     '=GoogleFinance(R[0]C[-5], "change")',
		     '=GoogleFinance(R[0]C[-6], "changepct")/100',
		     shares,
		     '=R[0]C[-7]*R[0]C[-1]'];
	
  service.getFeed(feedUrl, 
      function(entryRoot) {
          var insertRow = entryRoot.feed.entry.length+2;
	  var insertRowURI = cellFeedUrl + 
	      "?range=R" + insertRow + "C1" + escape(':') + "R" +
	      insertRow + "C" + cellEntries.length +
	      "&return-empty=true";
	  findCellEditURIs(service, insertRowURI, 
	      function(editURIs) { 
	        insertNewEntry_(service, insertRow, 1, cellEntries,
		    editURIs, succHandler, failHandler);
	      },
	      failHandler);	 
      },
      function(err) {
        failHandler(err); 
      });						 
}

/**
 * Inserts a new cell on the cellFe edUrl at row,column with the
 *  value from cellEntries[col].
 * 
 * @param {Object} service Google Spreadsheets GData service
 * @param {String} ticker the stock ticker
 * @param {String} shares the number of stock shares owned
 * @param {String} row the row to insert on
 * @param {String} col the column
 * @param {Array} cellEntries the array of column values representing 
 * the row to be inserted
 * @param {String} cellFeedUrl the cell feed URL to insert entries.
 * @param {Function} succHandler the function to be called on success
 * @param {Function} failHandler the function to be called on failure
 */
function insertNewEntry_(service, row, col, cellEntries, editURIs,
			succHandler, failHandler) {
  if (col >= cellEntries.length) return succHandler();
  var value = cellEntries[col];
  var dots = "...............";	
	
  var newEntry = {
      'xmlns':"http://www.w3.org/2005/Atom",
      'xmlns$openSearch':"http://a9.com/-/spec/opensearchrss/1.0/",
      'xmlns$gs':"http://schemas.google.com/spreadsheets/2006",                 
      'gs$cell': { 
        row: row, 
        col: col, 
        inputValue: value 
       }		
      };
				  
  service.updateEntry(editURIs[col], newEntry,
      function(entryRoot) {
      	displayError("Updating..."+dots.substring(0, col));
        insertNewEntry_(service, row, col+1, cellEntries, 
	    editURIs, succHandler, failHandler)								  },
      function(error) {
          failHandler("Could not insert value "+value+" at row " + 
	      row +", column " + col + " on " + editURIs[col], error);
      });
}

/**
 * Given an entry, find element with rel="edit"
 * @param {Object} entry
 * @return {String} the URI of the edit link, or "" if none was founded
 */
function findCellEditURIs(service, insertRowURI, succHandler, errorHandler) {
  var query = new google.gdata.client.Query(insertRowURI);
  service.getFeed(query.getUri(), 
		  function(feedRoot) {
		    findCellEditURIs_(feedRoot, succHandler);
		  }, errorHandler);
}

function findCellEditURIs_(feedRoot, succHandler) {
  var editURIs = [''];
  var entries = feedRoot.feed.entry;
  for (var i = 0; i < entries.length; i++) {
    var entry = entries[i];
    for (var j = 0; j < entry.link.length; j++) {
      var l = entry.link[j];
      if (l.rel == "edit" ) {
	editURIs.push(l.href);
	break;
      }
    }
  }
  succHandler(editURIs);
}


/**
 * Called when finished all the stock insertions, we hide preference pane 
 * and reload the front page.
 * 
 * @param {String} feedUrl the feedurl to load on the widget front
 * @param {username} usename username
 * @param {password} password password
 */
function finishUpdate(feedUrl, username, password)
{
  document.getElementById("newstock").value = "";
  displayError(" ");
  hidePrefs(); 
}


/**
 * makeKey makes the widget multi-instance aware 
 */
function makeKey(key) {
  return (widget.identifier + "-" + key);
}

/**
 * PREFERENCE BUTTON ANIMATION (- the pref flipper fade in/out)
 */
var flipShown = false;		

/**
 * A structure that holds information that is needed for the animation to run.
 */
var animation = {duration:0, starttime:0, to:1.0, now:0.0, 
  from:0.0, firstElement:null, timer:null};

/**
 * mousemove() is the event handle assigned to the onmousemove property 
 * on the front div of the widget. It is triggered whenever a mouse is moved 
 * within the bounds of your widget.  It prepares the
 * preference flipper fade and then calls animate() to performs the animation.
 */
function mousemove (event) {
  if (!flipShown)	{
    if (animation.timer != null) {
      clearInterval (animation.timer);
      animation.timer  = null;
    }
		
    var starttime = (new Date).getTime() - 13; 		
    animation.duration = 500;										animation.starttime = starttime;								    animation.firstElement = document.getElementById ('flip');		
    animation.timer = setInterval ("animate();", 13);						
    animation.from = animation.now;								
    animation.to = 1.0;										
    animate();											        flipShown = true;										
  }
}

/**
 * mouseexit() is the opposite of mousemove() in that it preps 
 * the preferences flipper to disappear.  It adds the appropriate 
 * values to the animation data structure and sets the 
 * animation in motion.
 */
function mouseexit (event) {
  if (flipShown) {
    if (animation.timer != null) {
      var username, password, spreadsheetKey, worksheetId, 
          feedUrl, newStock, shares;
      clearInterval (animation.timer);
      animation.timer  = null;
    }
		
    var starttime = (new Date).getTime() - 13;
    animation.duration = 500;
    animation.starttime = starttime;
    animation.firstElement = document.getElementById('flip');
    animation.timer = setInterval("animate();", 13);
    animation.from = animation.now;
    animation.to = 0.0;
    animate();
    flipShown = false;
  }
}

/**
 * animate() performs the fade animation for the preferences flipper. 
 * It uses the opacity CSS property to simulate a fade.
 */
function animate() {
  var T;
  var ease;
  var time = (new Date).getTime();
  T = limit_3(time-animation.starttime, 0, animation.duration);
	
  if (T >= animation.duration) {
    clearInterval (animation.timer);
    animation.timer = null;
    animation.now = animation.to;
  } else {
    ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
    animation.now = computeNextFloat (animation.from, animation.to, ease);
  }
  animation.firstElement.style.opacity = animation.now;
}

/**
 * these functions are utilities used by animate()
 */
function limit_3 (a, b, c) {
  return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease) {
  return from + (to - from) * ease;
}

/**
 * these functions are called when the info button itself 
 * receives onmouseover and onmouseout events
 */
function enterflip(event) {
  document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(event) {
  document.getElementById('fliprollie').style.display = 'none';
}
